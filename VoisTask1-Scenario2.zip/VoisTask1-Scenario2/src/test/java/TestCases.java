import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import javax.swing.*;
import java.util.Map;

public class TestCases  {



      @Test
    public void Testcase1forTask1Scenario2() throws InterruptedException {

        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();
        driver.get("https://www.amazon.com");
        Thread.sleep(8000);

          try {
              WebElement ChangeOrNotButton = driver.findElement(By.xpath("//*[@type='submit']"));
              ChangeOrNotButton.click();
              System.out.println("Button clicked successfully!");
          } catch (org.openqa.selenium.NoSuchElementException e) {
              System.out.println("Button not found on the page.");
          }
          Thread.sleep(2000);

          String TodaysDealKeyWord="goldbox";
          WebElement TodaysDealButton = driver.findElement(By.xpath("//a[contains(@href, '" + TodaysDealKeyWord + "')]"));
          TodaysDealButton.click();
          Thread.sleep(2000);


        /*
        * I Added this Item to My Selection Because the Number of pages
        * when we selected Headphones and Grocery the total number of pages is 2
        * */

          String BabyKeyWord="Baby Products";
          WebElement BabyCheckbox = driver.findElement(By.xpath("//span[text()='Baby Products']"));
          BabyCheckbox.click();

          String HeadPhonesKeyWord="Headphones & Earbuds";
          WebElement HeadphoneCheckbox = driver.findElement(By.xpath("//*[contains(text(), '" + HeadPhonesKeyWord + "')]"));
          HeadphoneCheckbox.click();


          String GroceryKeyWord="Grocery & Gourmet Food";
          WebElement GroceryCheckbox = driver.findElement(By.xpath("//*[contains(text(), '" + GroceryKeyWord + "')]"));
          GroceryCheckbox.click();



          String OfferKeyWord="10% off or more";
          //WebElement offerButton = driver.findElement(By.xpath("//*[contains(text(), '" + OfferKeyWord + "')]"));
          WebElement offerButton = driver.findElement(By.linkText("10% off or more"));
          offerButton.click();




         int GotoPage=4;
         int PageNumber =1;

          Thread.sleep(1000);

          String Str="2";
          /*WebElement NextButton = driver.findElement(By.xpath("//*[text()='2']"));
          NextButton.click();

          */
          //NextButton.submit();
         // Actions actions = new Actions(driver);
          //actions.moveToElement(NextButton).sendKeys(Keys.ENTER);

          //actions.click(NextButton).perform();
          //actions.moveToElement(NextButton).perform();
          //actions.sendKeys(Keys.ENTER).perform();

          //actions.moveToElement(NextButton).click();




          /*while(PageNumber!=GotoPage)
          {


              WebElement NextButton = driver.findElement(By.cssSelector("li.a-last"));
              NextButton.click();
              NextButton.sendKeys(Keys.ENTER);
              Thread.sleep(1000);
              System.out.println(PageNumber);

              PageNumber++;
          }*/






      }
    }



